window.addEventListener("load", () => {
    localStorage.setItem("name", document.querySelector("#login-jmeno").textContent);
})