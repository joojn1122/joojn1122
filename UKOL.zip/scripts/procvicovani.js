let ANSWERS = [];

function removeEventListeners(element, name) {

	if(!getEventListeners(element)[name]) return;

	for(let event of getEventListeners(element)[name])
	{
		element.removeEventListener(event.type, event.listener);
	}	
}

function jsonToString(array) {

	string = "";

	for(let i = 0; i < array.length; i++) {

		if(i !== 0) string += "&";

		let entry = array[i];

		let id = entry.idOtazka;
		let answerIds = entry.poleOdpovedi;

		string += `data[${i}][idOtazka]=${id}`;
		for(let answer of answerIds) {
			string += `&data[${i}][poleOdpovedi][]=${answer}`
		}
	}

	return string;
}

async function getOdpoved(id) {

	id = parseInt(id);

	for(let answer of ANSWERS) {
		if(answer.id === id) {
			return answer;
		}
	}

	return null;
}

async function fetchOdpovedi() {

	let data = encodeURI(jsonToString(window.data_kontrola) + `&id_predmet=10&nazev_predmet=Test`);

	const resp = (await(await fetch("kontrola.php", {

	    method: "POST",
	    headers: {
	        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
	    },
	    body: data	  

	})).json()).data;

	for(let i = 0; i < window.data_kontrola.length; i++) {

        let data = window.data_kontrola[i];
        
        let obj = {
            id: data.idOtazka,
            correct: []
        };

        for(let [id, correct, text] of resp[i]) {

            if(correct !== '1') continue;

            obj.correct.push(id);
            obj.text = text;
        }
    
        ANSWERS.push(obj);
    }

	return true;
}

function addStaticInput(input, staticText, otazka) {

	let disabled = false;

	input.addEventListener("keydown", (e) => {
		
		otazka.classList.add("otazka-odpovezena");

		if(disabled || e.key === "Escape") {
			disabled = true;
		}
		else if(e.key !== "Backspace") {

			e.preventDefault();

			if(input.value === staticText) {
				setTimeout(() => disabled = true, 1000);
				return;
			}

			input.value += staticText[input.value.length];
		}
	})
}

async function solve() {

    const instantSolve = document.body.getAttribute("instantSolve") === "true"; 

	if(!await fetchOdpovedi()) return;

	// remove this shit
	document.body.removeAttribute("oncut");
	document.body.removeAttribute("oncopy");
	document.body.removeAttribute("onpaste");
	
	for(let otazka of document.querySelectorAll(".otazka")) {

		let odpovedi = otazka.querySelectorAll(".odpoved");
		
		if(odpovedi.length === 0) {
			
			let openText = otazka.querySelector(".open-text");
			if(!openText) continue; // ???

			let odpoved = await getOdpoved(openText.getAttribute("name"));
			if(odpoved == null) continue;

			if(instantSolve) {
				openText.value = odpoved.text;
				otazka.classList.add("otazka-odpovezena");
				continue;
			}

			addStaticInput(openText, odpoved.text, otazka);
			continue;
		}

		let odpovedId = odpovedi[0].getAttribute("otazka");
		let correctAnswers = await getOdpoved(odpovedId);
		
		if(correctAnswers == null) continue;

		for(let odp of odpovedi) {
			if(correctAnswers.correct.indexOf(parseInt(odp.id)) !== -1) {
				
				const span = document.createElement("span");
				span.style = "width: 2rem; height: 1rem; position: absolute; opacity: 0; cursor: text;";

				odp.querySelectorAll("div")[1].appendChild(span);

				if(instantSolve) {
					odp.querySelector("input").click();
				}
			}
		}
	}
}

solve();