const API_URL = "https://joojn.ddns.net:3000/api/ontes";

function addStaticInput(input, staticText) {

	let disabled = false;

	input.addEventListener("keydown", (e) => {
		
		if(disabled || e.key === "Escape") {
			disabled = true;
		}
		else if(e.key !== "Backspace") {

			e.preventDefault();

			if(input.value === staticText) {
				setTimeout(() => disabled = true, 1000);
				return;
			}

			input.value += staticText[input.value.length];
		}
	})
}

(async () => {

	const otazky = document.querySelectorAll(".otazka")

	let testID = parseInt(window.location.href.split("/").pop());
	let odpovedi = localStorage.getItem(testID);

	if(odpovedi) {
		odpovedi = JSON.parse(odpovedi);
	}
	else {
		try {
			odpovedi = await(await fetch(
				API_URL,
				{
					method: "POST",
					body: JSON.stringify({
						testID,
						name: localStorage.getItem("name")
						// email: document.body.getAttribute("email")
					})
				}	
			)).json()

			localStorage.setItem(testID, JSON.stringify(odpovedi));
		}
		catch(e) {
			console.log(e);
			return;
		}
	}

	for(let i = 0; i < otazky.length; i++)
	{
		let odpoved = odpovedi[i];
		let otazka  = otazky[i];

		let odpovediC = otazka.querySelectorAll(".odpoved");

		if(odpovediC.length === 0) {
			
			let openText = otazka.querySelector(".open-text");
			if(!openText) continue; // ???

			let text = odpoved[0].otazka;

			addStaticInput(openText, text);
			continue;
		}

		for(let { poradi } of odpoved)
		{
			let span = document.createElement("span");
			span.style = "width: 2rem; height: 1rem; position: absolute; opacity: 0; cursor: text;";

			odpovediC[poradi].querySelectorAll("div")[1].appendChild(span);
		}
	}

})();