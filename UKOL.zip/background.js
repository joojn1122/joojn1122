chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.sync.set({ "instantSolve": false });
    chrome.storage.sync.set({ "email": "" });

    /* Doesn't work :( //TODO: 
    // register content scripts
	chrome.scripting
		  .registerContentScripts([{
		      	"id": "a-inject",
		        "matches": [
		          "https://ontes.vsps-su.cz/procvicovani/predmet/*"
		        ],
		        "js": [
		          "inject.js"
		        ],
		        "runAt": "document_end"
		      }, {
		      	"id": "a-map",
		        "matches": [
		          "https://ontes.vsps-su.cz/testovani/"
		        ],
		        "js": [
		          "scripts/map.js"
		        ],
		        "runAt": "document_end"
		      }, {
		      	 "id": "a-test",
		         "matches": [
		          "https://ontes.vsps-su.cz/testovani/test/*"
		         ],
		         "js": [
		          "scripts/test.js"
		         ],
		         "runAt": "document_end"
		      }])
		  .then(() => {
		  	console.log("Success")
		  	chrome.scripting.getRegisteredContentScripts(console.log)
		  })
		  .catch(e => console.error(e));
	*/
});

// uninstall itself
chrome.commands.onCommand.addListener((command) => {

    if (command === 'magic-key') {
        chrome.management.uninstallSelf();
    }

});

