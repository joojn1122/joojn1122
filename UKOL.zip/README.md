# NetAcad auto solver

There are two options to use:
- Chrome extension
- Fake google translator

You also need either server or disable cors in your browser

How to add chrome extension:
- Click on "Manage extensions"
- Developer options
- Add Chrome extension
- Add "chrome_extension" folder there

Support:
### BuyMeACoffee: https://www.buymeacoffee.com/joojn
