
function waitForElm(selector) {
    return new Promise(resolve => {
        if (document.querySelector(selector)) {
            return resolve(document.querySelector(selector));
        }

        const observer = new MutationObserver(mutations => {
            if (document.querySelector(selector)) {
                resolve(document.querySelector(selector));
                observer.disconnect();
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    });
}

window.addEventListener("load", () => {

	// add custom question count hook
	const select = document.querySelector("select");
	const option = document.createElement("option");
	select.appendChild(option);

	document.querySelectorAll(".box-tema").forEach(e => {
		e.addEventListener("click", () => {
			let value = document.querySelector("#celkem-otazek").textContent;

			option.value = value;
			option.textContent = value;
		})
	})

	// load procvicovani script
	// add generate button hook
	document.querySelector("#generovat-test").addEventListener("click", (e) => {

		let target = e.target;

		if(target.getAttribute("disabled"))
			return;

		waitForElm(".otazka").then(async () => {
			const { instantSolve } = await chrome.storage.sync.get("instantSolve");

			document.body.setAttribute("instantSolve", instantSolve.toString());
			
			// inject the actual script
			let script = document.createElement("script");
			script.src = chrome.runtime.getURL("scripts/procvicovani.js");

			script.onload = function() {
				this.remove();
			};

			(document.head || document.documentElement).appendChild(script);
		});
	})

})
	