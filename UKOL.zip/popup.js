const instantSolveInput = document.querySelector("#instantSolve");
const emailInput = document.querySelector("#email");

chrome.storage.sync.get("instantSolve", ({ instantSolve }) => {

	instantSolveInput.checked = instantSolve;

    instantSolveInput.addEventListener("change", () => {
        chrome.storage.sync.set({ instantSolve: instantSolveInput.checked });
    });

});


chrome.storage.sync.get("email", ({ email }) => {

	emailInput.value = email;

    emailInput.addEventListener("change", () => {
        chrome.storage.sync.set({ email: emailInput.value });
    });

});