const JavaScriptObfuscator = require('javascript-obfuscator');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

function readJSON(path) {

	const data = fs.readFileSync(path, 'utf8');

	return JSON.parse(data);

}

var copyRecursiveSync = function(src, dest) {
  var exists = fs.existsSync(src);
  var stats = exists && fs.statSync(src);
  var isDirectory = exists && stats.isDirectory();
  if (isDirectory) {
    fs.mkdirSync(dest);
    fs.readdirSync(src).forEach(function(childItemName) {
      copyRecursiveSync(path.join(src, childItemName),
                        path.join(dest, childItemName));
    });
  } else {
    fs.copyFileSync(src, dest);
  }
};


const dir = './obfuscated';

// remove obfuscated directory
if(fs.existsSync(dir)) {
	fs.rmSync(dir, { recursive: true, force: true });
}

fs.mkdirSync(dir);

const manifest = readJSON("manifest.json");
const originalManifest = readJSON("manifest.json");

function obfuscateFile(fileName, setVal, editContent) {
	
	let newName = obfuscateFileSelf(fileName, editContent)

	// let directoryName = path.dirname(value);
	// let newPath = path.join(directoryName, newName);

	setVal(newName);
}

function obfuscateFileSelf(fileName, editContent) {

	let newName = uuidv4().replaceAll("-", "") + path.extname(fileName);
	// let newName = path.basename(fileName);
	let content = fs.readFileSync(fileName, {encoding:'utf8', flag:'r'});

	if(editContent != undefined) {
		content = editContent(content);
	}

	if(fileName.endsWith('.js')) {
		/*
		let preset = JavaScriptObfuscator.getOptionsByPreset("default");
		preset.disableConsoleOutput = true;
		preset.stringArray = true;
		preset.stringArrayEncoding = "rc4";
		preset.stringArrayCallsTransform = true;
		preset.stringArrayCallsTransformThreshold = 0.75;
		preset.stringArrayRotate = true;
		preset.stringArrayThreshold = 0.75;
		preset.stringArrayWrappersCount = 1;
		preset.stringArrayIndexShift = true;
		preset.stringArrayWrappersChainedCalls = true;
		preset.stringArrayWrappersParametersMaxCount = 2;
		preset.stringArrayWrappersType = "variable";
		preset.stringArrayWrappersChainedCallsThreshold = 0.75;
		preset.stringArrayShuffle = true;
		preset.stringArrayIndexesType = "hexadecimal-number";
		preset.splitStrings = true;
		preset.splitStringsChunkLength = 10;
		*/
		
		content = JavaScriptObfuscator.obfuscate(content).getObfuscatedCode();
	}

	fs.writeFileSync(path.join(dir, newName), content);

	return newName;
}

// -- OBFUSCATION START --
obfuscateFile(
	manifest["background"]["service_worker"],
	(val) => {
		manifest["background"]["service_worker"] = val;
	}
)

let popup = obfuscateFileSelf("popup.js");  

obfuscateFile(
	manifest["action"]["default_popup"],
	(val) => {
		manifest["action"]["default_popup"] = val;
	},
	(content) => {
		return content.replaceAll("popup.js", popup)
	}
)

obfuscateFile(
	manifest["web_accessible_resources"][0]["resources"][0],
	(val) => {
		manifest["web_accessible_resources"][0]["resources"][0] = val;
	}
)


obfuscateFile(
	manifest["content_scripts"][0]["js"][0],
	(val) => {
		manifest["content_scripts"][0]["js"][0] = val;
	},
	(content) => {
		let cont = content.replaceAll(
			originalManifest["web_accessible_resources"][0]["resources"][0],
			manifest["web_accessible_resources"][0]["resources"][0]
		);

		return cont;
	}
)

obfuscateFile(
	manifest["content_scripts"][1]["js"][0],
	(val) => {
		manifest["content_scripts"][1]["js"][0] = val;
	}
)

obfuscateFile(
	manifest["content_scripts"][2]["js"][0],
	(val) => {
		manifest["content_scripts"][2]["js"][0] = val;
	}
)


fs.writeFileSync(path.join(dir, "manifest.json"), JSON.stringify(manifest));
copyRecursiveSync("images", path.join(dir, "images"));

console.log("Successfully obfuscated :)");
// -- OBFUSCATION END --