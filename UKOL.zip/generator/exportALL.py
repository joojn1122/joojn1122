import requests
import config
from bs4 import BeautifulSoup
from urllib.parse import quote
import generate
import answers
import json

ENDPOINT = "https://ontes.vsps-su.cz/procvicovani/"

headers = {
	"Cookie": config.PHP_SESSION,
	'Content-Type': 'text/html; charset=utf-8'
}

html = requests.get(ENDPOINT, headers=headers).text
soup = BeautifulSoup(html, 'html.parser')

ALL_ANSWERS = []
stack = []

for a in soup.find(class_="pas-4").find_all("a"):
	
	try:
		href = a.get("href")
		url = ENDPOINT + href

		title = a.get("title")
		predmet_id = href.split("/").pop()

		html = requests.get(url, headers=headers).text
		soup = BeautifulSoup(html, 'html.parser')

		all_count = 0
		url_string = f"id_predmet={predmet_id}&nazev_predmet={title}"

		for i, box in enumerate(soup.find(class_="pas-6").select(".box-tema")):

			count = int(box.get("pocet"))
			tema_id = box.get("tema-id")

			list_string = quote(f'data[{i}][]')
			url_string += f"&{list_string}={count}&{list_string}={tema_id}"

			all_count += count

		url_string += f"&pocet={all_count}"

		questions = generate.generateAnswers(url_string)
		correct_answers = answers.getAnswers(
			data=questions,
			id_predmet=predmet_id,
			nazev_predmet=title
		)

		ALL_ANSWERS.extend(correct_answers)

	except Exception as e:
		print(f"Something went wrong.. {e}")

print(f"Found {len(ALL_ANSWERS)} answers.")

with open("all-answers.json", "w") as f:
	json.dump(ALL_ANSWERS, f)