import requests
import urllib.parse
import json
import answers
import config

def generateAnswers(data) -> dict:

	ENDPOINT = "https://ontes.vsps-su.cz/procvicovani/generovani.php"

	resp = requests.post(ENDPOINT, data=data.encode('utf-8'), headers={
		"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
		"Cookie": config.PHP_SESSION
	})

	return resp.json()
