import requests
import urllib.parse
import config

def getAnswers(*, data, id_predmet, nazev_predmet) -> dict:

	ENDPOINT = "https://ontes.vsps-su.cz/procvicovani/kontrola.php"

	def jsonToString(array):

		string = ""

		for i in range(len(array)):

			if i != 0:
				string += "&"

			entry = array[i]

			id = entry["idOtazka"]
			answerIds = entry["poleOdpovedi"]

			string += urllib.parse.quote(f"data[{i}][idOtazka]") + f"={id}"
			
			for answer in answerIds:
				string += "&" + urllib.parse.quote(f"data[{i}][poleOdpovedi][]") + f"={answer}"

		return string

	wwwForm = jsonToString(data["data"]) + f"&id_predmet={id_predmet}&nazev_predmet={nazev_predmet}"

	resp = requests.post(ENDPOINT, data=wwwForm.encode('utf-8'), headers={
		"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
		"Cookie": config.PHP_SESSION
	})

	correct_answers = []

	for i, answers in enumerate(resp.json()["data"]):

		js = {	
			"id": data["data"][i]["idOtazka"],
			"correct": []
		}

		for answer_id, correct, answer_text in answers:
			if int(correct) == 1:
				js["correct"].append(answer_id)
				js["text"] = answer_text

		correct_answers.append(js)

	return correct_answers

